#include <math.h>
#include "funkcja.h"

// Przykladowa funkcja dwoch zmiennych: x*y
double myFun(double x,double y)
{
  return WSP*( exp(x) - log(y) ); 
}                  
