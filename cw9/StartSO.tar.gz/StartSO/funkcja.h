#ifndef FUNKCJA_H   // zapewnia najwyzej jednokrotne wlaczenie tego pliku
#define FUNKCJA_H 


#define WSP 5.0 // Staly wspolczynnik dla funkcji

// Przykladowa funkcja dwoch zmiennych: x*y 
double myFun(double x,double y);

#endif
